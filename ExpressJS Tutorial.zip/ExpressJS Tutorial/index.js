//ExpressJS is fast unopinionated and minimalist web framework of NodeJS 
//here npm is node package manager which allows installing
//more and more useful packages and libraries which are helpful for the using and working with framework
//npm i : for installing dependancies or packages like express or nodemon
//npm i express: installing express
//please do refer expressJS documentation for more

const express = require('express')
const path =require('path')
const app = express()
const port = 3000

//we can make/create own middleware and define it but mostly no need of making it
const middlewareAppu= (req,res,next)=>{
  console.log(req)
  next() //if we created many middlewares then to create sequence of which will be next middleware? --> we use this 
}

//app.use is middle ware that have access of both objects request and response and they can/may change them 
app.use(express.static(path.join(__dirname,"public"))) //dirname=variable, public=string (public serve for any public files that has to serve publicly on server) 
//to use created middleware mention it here
app.use(middlewareAppu)


// app.get('/', (req, res) => {
//   res.send('Hello World!')
// })

// app.get('/hello/:name', (req, res) => {
//   res.send('Hello World!'+ '  ' + req.params.name) //here we added parameter 'name' where name's value can be anything 
// })

app.get('/about', (req, res) => {
  //res.send('about')
  //res.sendFile(path.join(__dirname,'index.html')) //we can send file by using path module
  //res.status(500) //we can also set our error code as shown 
  res.json({"Name":"Apoorva"}) //we can send json files to server by using this command
}) 

//expressJS have nice thing that content type or headers also set by expressJS //Also do use 'json formatter' as we can load large files of json without trouble

//here we don't give address or msg then it will show error as cannot get
//actually, when we use nodeJS we have to tell separtely that if error occurs at endpoint send msg to client as 'cannot get' error by detecting 404 error code it doesn't have capability to detect it solely but if we use expressJS then server detects error code 
//we has to use if-else statements in nodeJS for same work but here no need for it
//ExpressJS really saves a lot of time

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`) //to create direct link
})

//many things we can do by nodeJS which also be done by expressJS 
//but node have hard code and writting if-else segments compared to 
//that express have pretty clean code

